/*******************************************************
Nom ......... : Exos.h
Auteurs ..... : Fabien RONDAN & Maxime WANG
Version ..... : 1.Release
********************************************************/

#pragma once

/**
 * @brief  Correspond au main du premier programme
*/
void exo1();

/**
 * @brief  Correspond au main du deuxi�me programme
*/
void exo2();

/**
 * @brief  Correspond au main du troisi�me programme
*/
void exo3();

/**
 * @brief  Correspond au main du quatri�me programme
*/
void exo4();

/**
 * @brief  Correspond au main du cinqui�me programme
*/
void exo5();

/**
 * @brief  Correspond au main du sixi�me programme
*/
void exo6();